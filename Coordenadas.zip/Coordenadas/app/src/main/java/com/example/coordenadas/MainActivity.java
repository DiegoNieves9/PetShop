package com.example.coordenadas;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore; // Importacion de firestore
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.DocumentReference;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import android.util.Log;




public class MainActivity extends AppCompatActivity {


    // Declaración de variables
    private static final int CODIGO_DE_PERMISOS_DE_UBICACION = 1001;

    private TextView textoCuentaAtras;
    private CountDownTimer cuentaAtras;
    private long tiempoRestante = 30000; // 30 segundos
    private final long countDownInterval = 1000; // intervalo de actualización en milisegundos

    private String switchColeccion = "Switch";
    private String activarDocument = "Activar_Localizacion";
    private FusedLocationProviderClient fusedLocationClient;
    //private FirebaseFirestore db;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private TextView tvDatos;


    //=================================================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) { //Configura la interfaz de usuario
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        db = FirebaseFirestore.getInstance(); // Inicializa firestore
        tvDatos = findViewById(R.id.tvDatos);

        textoCuentaAtras = findViewById(R.id.countdown_text);

        iniciarCuentaAtras(); // Iniciar el temporizador cuando se crea la actividad

        // Solicitar permisos en tiempo de ejecución
        solicitarPermisosDeUbicacion();
    }

    //=================================================================================================

    private void solicitarPermisosDeUbicacion() {
        // Verificar si los permisos ya han sido otorgados
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // Los permisos ya están otorgados
            obtenerUbicacion();  // Llama al método para obtener la ubicación
        } else {
            // Solicitar permisos en tiempo de ejecución
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    CODIGO_DE_PERMISOS_DE_UBICACION);
        }
    }
    //=================================================================================================

    private void obtenerUbicacion() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // Permiso de ubicación otorgado, continuar con la obtención de la ubicación
            fusedLocationClient.getLastLocation()
                    .addOnCompleteListener(this, new OnCompleteListener<android.location.Location>() {
                        @Override
                        public void onComplete(@NonNull Task<android.location.Location> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                double latitud = task.getResult().getLatitude();
                                double longitud = task.getResult().getLongitude();
                                String fechaHora = new Date().toString();

                                // Mostrar datos en TextView
                                String datos = "Latitud: " + latitud + "\nLongitud: " + longitud + "\nFecha y Hora: " + fechaHora;
                                tvDatos.setText(datos);

                                // Enviar datos a Firebase
                                enviarDatosAFirebase(latitud, longitud, fechaHora);
                            }
                        }
                    });
        } else {
            // El permiso de ubicación no ha sido otorgado
        }
    }

    //=================================================================================================

    private void enviarDatosAFirebase(double latitud, double longitud, String fechaHora) {
        Map<String, Object> datos = new HashMap<>();
        datos.put("Coordenadas", new GeoPoint(latitud, longitud));
        datos.put("Fecha", new Date());

        db.collection("Localizacion")
                .add(datos)
                .addOnCompleteListener(this, new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()) {
                            // Éxito al agregar datos a Firebase
                            Log.d("MainActivity", "Datos agregados a Firestore con ID: " + task.getResult().getId());
                        } else {
                            // Error al agregar datos a Firebase
                            Log.e("MainActivity", "Error al agregar datos a Firestore", task.getException());
                        }
                    }
                });
    }

    //=================================================================================================
    private void iniciarCuentaAtras() {
        cuentaAtras = new CountDownTimer(tiempoRestante, countDownInterval) {
            @Override
            public void onTick(long miliRestantes) {
                tiempoRestante = miliRestantes;
                actualizarTextoCuentaAtras();
            }

            @Override
            public void onFinish() {
                textoCuentaAtras.setText("¡Tiempo agotado!");

                // Verificar el estado de "Activar" en Firestore
                db.collection(switchColeccion).document(activarDocument)
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {
                                        Boolean activar = document.getBoolean("Activar");

                                        if (activar == true && activar) {
                                            // La localización está activada
                                            textoCuentaAtras.setText("¡Activada!");

                                            obtenerUbicacion();

                                        } else {
                                            // La localización está desactivada
                                            textoCuentaAtras.setText("¡Desactivada!");
                                        }
                                    } else {
                                        Log.d("Firestore", "El documento no existe");
                                    }
                                } else {
                                    // Manejar el error si ocurre
                                    Log.e("Firestore", "Error al obtener datos: ", task.getException());
                                }
                            }
                        });

                // Reiniciar automáticamente el temporizador después de un breve retraso
                textoCuentaAtras.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        resetTimer();
                    }
                }, 2000); // 2 segundos de retraso antes de reiniciar
            }
        }.start();
    }

    //=================================================================================================
    private void resetTimer() {
        tiempoRestante = 30000; // Restablecer el tiempo en 30 segundos
        iniciarCuentaAtras(); // Iniciar el temporizador nuevamente
    }

    //=================================================================================================
    private void actualizarTextoCuentaAtras() {
        // Calcula los minutos y segundos a partir del tiempo restante en milisegundos
        int minutes = (int) (tiempoRestante / 1000) / 60;
        int seconds = (int) (tiempoRestante / 1000) % 60;

        // Formatea el tiempo en una cadena con el formato "mm:ss"
        String horaFormateada = String.format("%02d:%02d", minutes, seconds);

        // Actualiza el TextView en la interfaz de usuario con el tiempo formateado
        textoCuentaAtras.setText(horaFormateada);
    }
    //=================================================================================================

}